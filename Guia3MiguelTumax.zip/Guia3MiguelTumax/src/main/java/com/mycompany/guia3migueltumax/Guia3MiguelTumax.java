/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.guia3migueltumax;

/**
 *
 * @author tumax
 */
public class Guia3MiguelTumax {

    public static void main(String[] args) {
        //RECUERDE QUITAR LAS DIAGONALES A LOS PROBLEMAS QUE USTED QUIERE QUE SE MUESTREN
        
        //ejercicioShowMessageDialog window1 = new ejercicioShowMessageDialog();
        //window1.setVisible(true);
        //ejercicioShowConfirmDialog window2 = new ejercicioShowConfirmDialog();
        //window2.setVisible(true);
        //ejercicioShowInputDialog window3 = new ejercicioShowInputDialog();
        //window3.setVisible(true);
        //InicioSesion window4 = new InicioSesion();
        //window4.setVisible(true);
        //problema2 window5 = new problema2();
        //window5.setVisible(true);
    }
}
